export default function Home() {
  return (
    <main className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-6xl mx-auto py-10">
        <header className="mb-12 text-center">
          <h1 className="text-4xl font-bold text-blue-800">CloudSilver IT</h1>
          <p className="text-lg text-gray-600 mt-2">Smart. Secure. Connected.</p>
        </header>

        <section className="mb-16">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Our Services</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow">
              <h3 className="text-xl font-semibold text-blue-700">Cloud Solutions</h3>
              <ul className="list-disc list-inside text-gray-700 mt-2">
                <li>Cloud setup & migration (AWS, Azure)</li>
                <li>Data backup & disaster recovery</li>
                <li>Remote collaboration tools</li>
              </ul>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow">
              <h3 className="text-xl font-semibold text-blue-700">Cybersecurity</h3>
              <ul className="list-disc list-inside text-gray-700 mt-2">
                <li>Network & endpoint protection</li>
                <li>Penetration testing</li>
                <li>Compliance (HIPAA, PCI-DSS)</li>
              </ul>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow">
              <h3 className="text-xl font-semibold text-blue-700">Web Design</h3>
              <ul className="list-disc list-inside text-gray-700 mt-2">
                <li>Responsive websites</li>
                <li>SEO & UX optimization</li>
                <li>Custom integrations</li>
              </ul>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow">
              <h3 className="text-xl font-semibold text-blue-700">Smartphone Support</h3>
              <ul className="list-disc list-inside text-gray-700 mt-2">
                <li>Mobile apps & MDM</li>
                <li>Secure device configuration</li>
                <li>Support for retirees</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="text-center">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Contact Us</h2>
          <p className="text-gray-700 mb-2">Serving Marco Island, Naples, Fort Myers – expanding to Miami</p>
          <p className="text-gray-700">Email: info@cloudsilverit.com | Phone: (239) XXX-XXXX</p>
        </section>
      </div>
    </main>
  );
}
